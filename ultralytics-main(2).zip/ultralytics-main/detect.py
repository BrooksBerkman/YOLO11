

from ultralytics import YOLO

if __name__ == '__main__':

    # Load a model
    model = YOLO(model=r'D:\2-Python\1-YOLO\YOLOv11\ultralytics-8.3.2\yolo11n-seg.pt')
    model.predict(source=r'D:\2-Python\1-YOLO\YOLOv11\ultralytics-8.3.2\ultralytics\assets\bus.jpg',
                  save=True,
                  show=True,
                  )
